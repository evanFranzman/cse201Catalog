<?php

$conn = mysql_connect('localhost','root','root');
mysql_select_db("Game");

if($conn){
    echo "connected";
} else {
    echo "i hate you";
}

class Game {
    //instance variables
    private $gameId;
    private $gameName;
    private $userId;
    private $genreTypeId;
    private $releaseDate;
    private $currentVersion;
    private $websiteLink;
    private $logoId;

    //constructor 
    function _construct( $gameId, $gameName, $userId, $genreTypeId, $releaseDate, $currentVersion,
        $websiteLink, $logoId){
            $this->gameId = $gameId;
            $this->gameName = $gameName;
            $this->userId = $userId;
            $this->genreTypeId = $genreTypeId;
            $this-> currentVersion = $currentVersion;
            $this->releaseDate = $releaseDate;
            $this->currentVersion = $currentVersion;
            $this->websiteLink = $websiteLink;
            $this->logoId = $logoId;
  }  
  
  //getters 
  public function getGameId(){
      return $this->gameId;
  }
  
  
  public function getGameName(){
      return $this->gameName;
  }
  
  
  public function getUserId(){
      return $this->userId;
  }
  
  public function getGenreTypeId(){
      return $this->genreTypeId;
  }
  
  public function getReleaseDate(){
      return $this->releaseDate;
  }
  
  public function getCurrentVersion(){
      return $this->currentVersion;
  }
  
  public function getWebsiteLink(){
      return $this->websiteLink;
  }
  
  public function getLogoId(){
      return $this->logoId;
  }
  
  //setters
  public function setGameId($gameId){
      $this->gameId = $gameId;
  }
  
  public function setGameName($gameName){
      $this->gameName = $gameName;
  }
  
  public function setUserId($userId){
      $this->userId = $userId;
  }
  
  public function setGenreTypeId($genreTypeId){
      $this->genreTypeId = $genreTypeId;
  }
  
  public function setReleaseDate($releaseDate){
      $this->releaseDate = $releaseDate;
  }
  
  public function setCurrentVersion($currentVersion){
      $this->currentVersion = $currentVersion;
  }
  
  public function setWebsiteLink($websiteLink){
      $this->websiteLink = $websiteLink;
  }
  
  public function setLogoId($logoId){
      $this->logoId = $logoId;
  }
  
  public function getLogo($gameName){
      
      //connect to database
      //query through entire database for game name
      //???
      //???
      //profit?
  }   
}
?>
