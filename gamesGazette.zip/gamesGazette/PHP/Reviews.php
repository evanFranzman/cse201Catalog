<?php
class Reviews{
    
    private $game = null;
    private $date = null;
    private $review = null;
    private $replies = null;
    
    public function  _construct($review, $game, $date, $replies) {
        $this->review = $review;
        $this->game = $game;
        $this->date = $date;
        $this->replies = $replies;
    }
    
    function getReview() {
        return $this->review;
    }
    
    function setReview($review) {
        $this->review = $review;
    }
    
    function getGame(){
        return $this->game;
    }
    
    function setGame($game){
        $this->game = $game;
    }
    
    function getDate(){
        return $this->date;
    }
    
    function setDate(string $date){
        $this->date = $date;
    }
    
    function getReplies(){
        return $this->replies;
    }
    
    function setReplies(string $replies){
        $this->replies = $replies;
    }
}
?>
