<?php
class User{
	private $userId = null;
	private $userName = null;
	private $userType = null;
	private $password = null;
	private $email = null;
	private $companyName = null;

	private function _construct(int $userId, string $userName, int $userType, string $password, string $email, string $companyName){
		$this->email 	   = $email;
		$this->userId 	   = $userId;
		$this->userName    = $userName;
		$this->userType    = $userType;
		$this->password    = $password;
		$this->companyName = $companyName;
	}

	//getters
	public function getUserId(){
		return $this->userId;
	}
	public function getUserName(){
		return $this->userName;
	}
	public function getUserType(){
		return $this->userType;
	}
	public function getEmail(){
		return $this->email;
	}
	public function getPassword(){
		return $this->password;
	}
	public function getCompanyName(){
		return $this->companyName;
	}
	
	//setters
	public function setUserId($userId){
	    $this->userId = $userId;
	}
	
	public function setUserName($userName){
	    $this->userName = $userName;
	}
	
	public function setUserType($userType){
	    $this->userType = $userType;
	}
	
	public function setEmail($email){
	    $this->email = $email;
	}
	
	public function setPassword($password){
	    $this->password = $password;
	}
	
	public function setCompanyName($companyName){
	    $this->companyName = $companyName;
	}
	

	public function verifyLogin(string $email, string $password){
		if ($this->email == $email && $this->password == $password){
			return true;
		} else {
			return false;
		}
	}
}



?>
