<?php
        $conn = mysql_connect('localhost','root','root');
        mysql_select_db("Game");
	
	if($conn){
		echo "connected. and i'll have you know, its totally me and not you, so don't be worried. ;)";
	} else {
		echo "i love you but please understand that we have to make this work. if you can't understand that, then its definitely you and not me. sorry. thats just how the world works. tough.";
	}
?>

