# cse201Catalog
I went ahead and created the repository and project for us on github, despite being a little inexperienced with the software. If you guys have any suggestions or anything for me to change or add please let me know or go ahead and do it yourself because I am completely new to all of this. Hopefully we can self-manage and create a functional way of doing things.
