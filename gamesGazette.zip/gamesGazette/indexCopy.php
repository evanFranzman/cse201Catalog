<?php
include "config/config.php";
session_start();
?>
<!DOCTYPE html>
<html>
<head>
<style>
<!��Code based off w3 Schools 
Title: Responsive Website Layout
Author: W3Schools 
Date: 2020
Code Version: 1.0
Availabilty: https://www.w3schools.com/css/tryit.asp?filename=trycss_website_layout_blog
-->
* {
  box-sizing: border-box;
}


body {
  font-family: Courier New;
  padding: 10px;
  background: #393e41;
}


/* Header/Blog Title */
.header {
  padding: 30px;
  text-align: center;
  background: #7B868C;
}


.header h1 {
  font-size: 50px;
}


h2 {
  text-align: center;
}


.header p {
  font-style: italic;
}


.card{
  background-color: #7B868C;
  padding-top: 5px;
  padding-left: 5px;
  padding-bottom: 5px;
}


/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: #333;
}


/* Style the topnav links */
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}


/* Change color on hover */
.topnav a:hover {
  background-color: #256EFF;
  color: black;
}


/* Create two unequal columns that floats next to each other */
/* Left column */
.leftcolumn {   
  float: left;
  width: 75%;
}


/* Right column */
.rightcolumn {
  float: left;
  width: 25%;
  background-color: #f1f1f1;
  padding-left: 20px;
}


/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}


/* Footer */
.footer {
  padding: 5px;
  text-align: right;
  background: #333;
  color: #f2f2f2;
}


.footer h2{
  text-align: left;
}


/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 800px) {
  .leftcolumn, .rightcolumn {   
    width: 100%;
    padding: 0;
  }
}


/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .topnav a {
    float: none;
    width: 100%;
  }
}
</style>
<title>Game Gazette</title>
<link rel="stylesheet" type="text/css" href="/public/CSS/game_style.css">
</head>
<body>

<div class="header">
  <h1>Game Gazette</h1>
  <p>**Insert slogan here</p>
</div>

<div class="topnav">
  <a href='index.php'>Game List</a>
  <a href="/templates/requestReview.php">Request a Review</a>
  <a href="/templates/login.php" style="float:right">Login</a>
</div>

<div class="row">
    <div class="card">
      <h2>Game List</h2>
	<p>See our games below...</p>
	<?php
                $qry = "SELECT g.gameName, g.websiteLink, l.logoBody FROM Game.Games g, Game.Logos l WHERE g.logoId = l.logoId ORDER BY g.gameName;";
                $res = mysql_query($qry) or die (mysql_error());
                while($row=mysql_fetch_assoc($res)){
                        echo "<img src=\"".$row['logoBody']."\" alt=\"Error\" style=\"width:300px;height:300px;\">";
                        echo "<p><a href=\"".$row['websiteLink']."\">".$row['gameName']."</a></p>";
                }
        ?>
    </div>
</div>

<div class="footer">
  <p>
  Scrum Bags Corp.
  </p>
  <a href="about_us.html">About Us</a>
</div>

</body>
</html>
