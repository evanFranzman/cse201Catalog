

<!DOCTYPE html>
<html>
<head>
<style>
</style>
<title>Game Gazette</title>
<link rel="stylesheet" type="text/css" href="game_style.css">
</head>
<body>

<div class="header">
  <h1>Game Gazette</h1>
  <p></p>
</div>

<div class="topnav">
  <a href="../index.php">Game List</a>
  <a href="/templates/requestReview.php">Request a Review</a>
  <a href="/templates/login.php" style="float:right">Login</a>
</div>

<div class="row">
    <div class="card">
	<h2>About Us</h2>
	<h3>Bryan Afadzi</h3>
	<img src='photos/bryan.jpg' class='aboutImage' height='200' width='200'> 
	<h4>Data Layer/Developer</h4>
	<p>
	Bryan is a sophomore, computer science major. He is Dr. Stephan's favorite
	student. 
      </p>
    </div>

    <div class="card">
        <h3>Kabir Arora</h3>
	<h4>Developer</h4>
        <img src='photos/kabir.jpg' class='aboutImage' height='200' width='200'>
        <h4>Developer</h4>
        <p>             
	Kabir is a sophomore, computer science major. He is Dr.Stephan's favorite student.
      </p>
    </div>

   <div class="card">
	<h3>Henry Deal</h3>
	<img src='photos/henry.jpg' class='aboutImage' height='200' width='200'>
	<h4>Technical Manager</h4>
	<p> 
	Henry is a sophomore, computer science major. He is Dr. Stephan's favorite student.
	</p> 
  </div>

  <div class="card">
	<h3>Evan Franzman</h3>
	<img src='photos/evan.jpg' class='aboutImage' height='200' width='200'>
	<h4>Data Layer/Developer</h4>
	<p>
	Evan is a sophomore, computer science major. He is Dr. Stephan's favorite student.
	</p>
  </div>

  <div class="card">
	<h3>Micki Smolenski</h3>
	<img src='photos/micki.jpg' class='aboutImage' height='200' width='200'>
	<h4>Project Manager</h4>
	<p>
	Micki is a junior, software engineering major. She is Dr. Stephan's favorite student.
	</p>
   </div>
<div class="footer">
  <p>
  Scrum Bags Corp.
  </p>
  <a href="aboutus.php">About Us</a>
<br>
<a href="helpme.php">Help</a> 
</div>

</body>
</html>


