<?php
include "../config/config.php";
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <!-- Tags and Bootstrap CSS from getBootstrap.com
    Title: Introduction
    Author: getBootstrap.com
    Date: 2020
    Code Version: 1.0
    Availability: https://getbootstrap.com/docs/4.4/getting-started/introduction/ 
    -->
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="game_style.css">
  
<style>
<!��Code based off w3 Schools 
Title: Responsive Website Layout
Author: W3Schools 
Date: 2020
Code Version: 1.0
Availabilty: https://www.w3schools.com/css/tryit.asp?filename=trycss_website_layout_blog
-->
</style>
<title>Game Gazette: Create an Account</title>
</head>
<body>

<div class="header">
  <h1>Game Gazette</h1>
  <p>**Insert slogan here</p>
</div>

<div class="topnav">
  <a href='../index.php'>Game List</a>
  <a href="requestReview.php">Request a Review</a>
  <a href="login.php" style="float:right">Login</a>
  
</div>
	<div class="card">
      <h2>Create an Account</h2>
      <form method="Post" action="">
        <div class="form-group">
        <label for="email">Email</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="example@email.com">
       </div>
        <div class="form-group">
        <label for="firstName">First Name</label>
        <input type="text" class="form-control" id="firstName" name="firstName" placeholder="John">
       </div>
        <div class="form-group">
        <label for="lastName">Last Name</label>
        <input type="text" class="form-control" id="lastName" name="lastName" placeholder="Doe">
       </div>
        <div class="form-group">
        <label for="companyName">Company Name</label>
        <input type="text" class="form-control" id="companyName" name="companyName" placeholder="Optional">
       </div>
       <div class="form-group">
    <label for="userName">Username</label>
    <input type="text" class="form-control" id="userName" name="userName"  placeholder="Username"> 
  </div>
       <div class="form-group">
    <label for="password">Password</label>
    <input type="password" class="form-control" id="password" name="password"  placeholder="Password">    
  </div>
   <div class="form-group">
    <label for="repassword">Repeat Password</label>
    <input type="password" class="form-control" id="repassword" placeholder="Repeat Password">    
  </div>
    <button type="submit" class="btn btn-primary" name="Submit">Submit</button>
      </form>
</div>

<div class="footer">
  <p>
  Scrum Bags Corp.
  </p>
  <a href="aboutus.php">About Us</a>
<br>                                                                                                                                             
<a href="helpme.php">Help</a>
</div>
<?php
	$qry = "select Null from Users where exists (select email from Users where email = '".$_POST['email']."');";
	$res = mysql_query($qry) or die (mysql_error());
	if(mysql_num_rows($res) === 0)
	{
		$qry ="INSERT INTO Users (userType, firstName, lastName, userName, password, email) VALUES(1, '".$_POST['firstName']."','".$_POST['lastName']."', '".$_POST['userName']."', '".$_POST['password']."', '".$_POST['email']."');";
        	$res= mysql_query($qry) or die (mysql_error());
        	while ($row=mysql_fetch_assoc($res)) {
                	        header("Location: login.php");

  	     	}
	}
	else if (isset($_POST["Submit"])){
		echo '<script>alert("Account already exists. Please create a new account.")</script>';
	}

?>
</body>
</html>



