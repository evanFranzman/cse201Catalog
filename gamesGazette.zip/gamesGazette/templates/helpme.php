

<!DOCTYPE html>
<html>
<head>
<style>
</style>
<title>Game Gazette</title>
<link rel="stylesheet" type="text/css" href="game_style.css">
</head>
<body>

<div class="header">
  <h1>Game Gazette</h1>
  <p></p>
</div>

<div class="topnav">
  <a href="../index.php">Game List</a>
  <a href="/templates/requestReview.php">Request a Review</a>
  <a href="/templates/login.php" style="float:right">Login</a>
</div>

<div class="row">
    <div class="card">
	<h2>Help Page</h2>
		<p>
		Hello and welcome to our site! Here, you will be able to
		<ul>
			<li>
		</ul>
		</p>
   </div>
</div>
<div class="footer">
  <p>
  Scrum Bags Corp.
  </p>
  <a href="aboutus.php">About Us</a>
<br>                                                                                                                                             
<a href="helpme.php">Help</a>
</div>

</body>
</html>


