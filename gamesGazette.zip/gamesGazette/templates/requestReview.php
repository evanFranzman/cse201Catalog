<?php
include "../config/config.php";
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <!-- Tags and Bootstrap CSS from getBootstrap.com
    Title: Introduction
    Author: getBootstrap.com
    Date: 2020
    Code Version: 1.0
    Availability: https://getbootstrap.com/docs/4.4/getting-started/introduction/ 
    -->
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="game_style.css">
  
<style>
</style>
<title>Game Gazette: Create an Account</title>
</head>
<body>

<div class="header">
  <h1>Game Gazette</h1>
  <p>**Insert slogan here</p>
</div>

<div class="topnav">
  <a href="../index.php">Game List</a>
  <a href="requestReview.php">Request a Review</a>
  <a href="login.php" style="float:right">Login</a>
  
</div>

	<div class="card">
<h2>Request a Review</h2>
      <form action='' method="Post">
        <div class="form-group">
        <label for="email">Email</label>
        <input type="email" class="form-control" id="email" name="email" placeholder="example@email.com">
       </div>
       <div class="form-group">
    <label for="gameRequested">Name of Game</label>
    <input type="text" class="form-control" id="gameRequested" name="gameRequested" placeholder="Name of Game"> 
  </div>
	<div class="form-group">
		<label for="details">Details</label>
		<textarea class="form-control" id="details" name="details" rows="3"></textarea>
	</div>
    <button type="submit" class="btn btn-primary">Submit</button>
      </form>
	</div>
<div class="footer">
  <p>
  Scrum Bags Corp.
  </p>
  <a href="aboutus.php">About Us</a>
<br>                                                                                                                                             
<a href="helpme.php">Help</a>

</div>

<?php
	$gameId = "SELECT g.gameId FROM Game.Games g WHERE g.gameName = ".$_POST['gameRequested'].";";
	$userId = "SELECT u.userId FROM Game.Users u WHERE u.email = ".$_POST['email'].";";
	$text = $_POST['details'];
	$insert = "INSERT INTO Game.Reviews (gameId, userId, text) VALUES ((SELECT g.gameId FROM Game.Games g WHERE g.gameName = ".$_POST['gameRequested']."), (SELECT u.userId FROM Game.Users u WHERE u.email = ".$_POST['email']."), ".$_POST['details'].");";
	$res= mysql_query($insert) or die (mysql_error());
	while ($row=mysql_fetch_assoc($res)) {
             header("index.php");
	
        }
?>

</body>
</html>



